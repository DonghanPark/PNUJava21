import java.util.ArrayList;
import java.util.Objects;

public class FootballClub {
    private String name;
    private final int maxSquadSize = 25;

    private ArrayList<Player> squad = new ArrayList<Player>();

    public FootballClub(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FootballClub that = (FootballClub) o;
        return maxSquadSize == that.maxSquadSize && Objects.equals(name, that.name) && Objects.equals(squad, that.squad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, maxSquadSize, squad);
    }

    public String toString() {
        String msg = "\nFootballClub Name: " + name + " Player Count: " + squad.size() + "\n";
        for (int i = 0; i < squad.size(); i++) {
            msg += "\t" + squad.get(i) + "\n";
        }
        return msg;
    }

    public void addPlayer(Player newPlayer) {
        squad.add(newPlayer);
    }

    public void removeAllPlayer() {
        for (int i = 0; i < squad.size(); i++) {
            squad.clear();
        }
    }

    public Player findPlayer(String playerFirstName, int jerseyNumber) {
        for (int i = 0; i < squad.size(); i++) {
            if (playerFirstName.equals(squad.get(i).getFirstName())
                && jerseyNumber==squad.get(i).getJerseyNumber()) {
                return squad.get(i);
            }
        }
        return null;
    }
    // other methods including constructor, equials(), hashCode()
}
