package edu.pnu.admin;
import edu.pnu.collection.*;
public class Player {
    private String firstName;
    private String lastName;
    private int jerseyNumber;

    public Player(String firstName, String lastName, int jerseyNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jerseyNumber = jerseyNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getJerseyNumber() {
        return jerseyNumber;
    }

    public void setJerseyNumber(int jerseyNumber) {
        this.jerseyNumber = jerseyNumber;
    }

    @Override
    public String toString() {
        return "[" + lastName +
                "," + firstName +
                ","+ jerseyNumber +
                "]";
    }
}
