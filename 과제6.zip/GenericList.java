package edu.pnu.collection;
import edu.pnu.admin.*;
public class GenericList<T> {
    private static final int DEFAULT_SIZE = 10;
    private Object[] data;
    private int size = 0;
    private int GenericList = 0;

    public GenericList() {
        this.data = new Player[DEFAULT_SIZE];
    }

    public void add(T newPlayer) {
        data[size] = newPlayer;
        size++;
    }

    public int size() {
        return size;
    }

    public T get(int i) {
        return (T) data[i];
    }

    public void GenericListclear() {
        this.data = new Player[DEFAULT_SIZE];
        size = 0;
    }
}