package com.cafe.menu;

public class Coffee extends Beverage {
    private int defaultShot;

    public Coffee(String name) {
        super(name, 4100, TALL);
    }

    @Override
    public boolean setSize(int size) {
        if(size == GRANDE) {
            super.setSize(size);
            super.basePrice = super.basePrice+500;
            return true;
        }
        return false;
    }
}
