package com.cafe.menu;
import com.cafe.order.*;
public abstract class Beverage {
    public static final int TALL = 0;
    public static final int GRANDE = 1;
    public static final int VENTI = 2;
// TALL 을 기준 금액으로 크기별(GRANDE, VENTI)로 500원, 1000원 추가됩니다.
    public String name; public int basePrice; public int size;

    public Beverage(String name, int basePrice, int size) {
        this.name = name;
        this.basePrice = basePrice;
        this.size = size;
    }

    public boolean setSize(String size) {
        if ("TALL".equals(size))
            return setSize(TALL);
        else if ("GRANDE".equals(size))
            return setSize(GRANDE);
        else if ("VENTI".equals(size))
            return setSize(VENTI);
        return false;
    }

    public boolean setSize(int size) {
        if (size == TALL) {
            this.size = size;
            return true;
        }
        else if (size == GRANDE) {
            this.size = size;
            return true;
        }
        else if (size == VENTI) {
            this.size = size;
            return true;
        }
        return false;
    }


    public String returnString() {
        if (this.size == 0) {
            return "TALL";
        }
        else if (this.size == 1) {
            return "GRANDE";
        }
        else if (this.size == 2) {
            return "VENTI";
        }
        return "";
    }

}
