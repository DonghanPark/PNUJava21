package com.cafe.order;
import com.cafe.menu.Beverage;
public class OrderItem {
    Beverage beverage;
    int quantity;

    public OrderItem(Beverage beverage, int quantity) {
        this.beverage = beverage;
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "[ name=" + beverage.name +
                ", Price=" + beverage.basePrice +
                ", size=" + beverage.returnString() +
                ", quantity=" + quantity +
                " ]";
    }
}
