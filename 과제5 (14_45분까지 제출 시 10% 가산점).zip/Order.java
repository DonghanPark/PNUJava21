package com.cafe.order;
import com.cafe.menu.*;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<OrderItem> items = new ArrayList<OrderItem>();

    public void add(OrderItem item) {
        items.add(item);
    }

    public int cost() {
        int sum = 0;
        for (int i = 0; i < items.size(); i++) {
            sum = sum + (items.get(i).beverage.basePrice * items.get(i).quantity);
        }
        return sum;
    }

    public boolean setSize(String name, String size) {
        for (int i = 0; i < items.size(); i++) {
            if( items.get(i).beverage.name.equals(name) )
                return items.get(i).beverage.setSize(size);
        }
        return false;
    }

    public void print() {
        for (int i = 0; i < items.size(); i++) {
            String temp = "[ name=" + items.get(i).beverage.name +
                    ", Price=" + items.get(i).beverage.basePrice +
                    //", size=" + returnString(items.get(i).beverage.size) +
                    ", size=" + items.get(i).beverage.returnString() +
                    ", quantity=" + items.get(i).quantity + " ]";
            System.out.println(temp);
        }
        System.out.printf("Total: %,d%n", cost());
    }
}
