import java.util.Scanner;

public class FactorialMain {
    public static void main(String[] arg) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int num1 = scanner.nextInt();

        for (int i = 1; i <= num1; i++) {
            System.out.println("Factorial of " + i + " = " +getFactorial(i));
        }

        scanner.close();
    }
    private static long getFactorial(final int n) {
        if (n == 1) return 1;
        else return n*getFactorial(n-1);
    }
}
