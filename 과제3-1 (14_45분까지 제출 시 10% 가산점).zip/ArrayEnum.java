import java.util.Scanner;
enum Command {QUIT, ADD, LIST, AVG, SUM, STD, INVALID}

public class ArrayEnum {
    public static void main(String[] args) {
        int [] values = new int[100];
        int index = 0;

        final Scanner scanner = new Scanner(System.in);

        while ( true ) {
            final Command command = getCommand(scanner);
            if ( command == Command.QUIT ) {
                System.out.println("Bye!");
                break;
            }
            switch ( command ) {
                case ADD:
                    final int newValue = getValue(scanner);
                    values[index] = newValue;
                    index++;
                    break;
                case LIST:
                    printList(values, index);
                    break;
                case AVG:
                    System.out.printf("%.2f%n", getAvg(values, index));
                    break;
                case SUM:
                    System.out.printf("%d\n", getSum(values, index));
                    break;
                case STD:
                    System.out.printf("%.2f%n", getStd(values, index));
                    break;
                case INVALID:
                    System.out.print("Invalid Command\n");
                    break;
                default:
                    break;
            }
        }
        scanner.close();
    }

    private static double getStd(int[] values, int index) {
        double avg = getAvg(values, index);
        double temp = 0;
        for (int i = 0; i < index; i++) {
            temp = temp + Math.pow((values[i]-avg), 2);
        }
        double var = temp/index;
        return Math.sqrt(var);
    }

    private static int getSum(int[] values, int index) {
        int sum = 0;
        for (int i = 0; i < index; i++) {
            sum = sum + values[i];
        }
        return sum;
    }

    private static double getAvg(int[] values, int index) {
        int sum = getSum(values, index);
        return sum / (double)index;
    }

    private static void printList(int[] values, int index) {
        for (int i = 0; i < index; i++) {
            System.out.printf("%d ", values[i]);
        }
        System.out.print("\n");
    }

    private static int getValue(Scanner scanner) {
        return scanner.nextInt();
    }

    private static Command getCommand(Scanner scanner) {
        String input = scanner.next();
        try {
            return Command.valueOf(input.toUpperCase());
        }
        catch ( IllegalArgumentException e ) {
            return Command.INVALID;
        }
    }

}